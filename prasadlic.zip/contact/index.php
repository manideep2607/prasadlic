<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Prasad LIC</title>
<?php include('../includes/files.html'); ?>

</head>
<body>
<?php include('../includes/global-nav.html'); ?>
<div id="content-wrap">
    <div id="banner">
    <img src="../img/profile.jpg" />
    </div>
</div>
</body>