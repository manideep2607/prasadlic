    <div id="agent_login">
        <div id="login_panel">
        <div id="load"></div>
        	<form name="agent_login" onsubmit="return verifyForm()" method="post" action="login.php" >
            	<p id="error"></p>
                <input id="code" name="code" type="text" placeholder="Your Agent Code" class="textbox"/>
                <input id="pwd" name="pwd" type="password" placeholder="Password" class="textbox" />
                <input name="submit" type="submit" value="Login" class="button" />
            </form>
            <p>Not in LIC? - <a href="../career/">Join us</a></p>
            <a class="help" title="Contact PSNVN Prasad">Help?</a>
        </div>
    </div>